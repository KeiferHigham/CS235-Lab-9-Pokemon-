#ifndef POKEMON_HASHMAP_H
#define POKEMON_HASHMAP_H
#include "HashMapInterface.h"
#include "Pair.h"
#include "sstream"
#include <algorithm>

#define DEFAULT_MAP_HASH_TABLE_SIZE	31
#define HASH_CONSTANT				3
#define LOAD_THRESHOLD				75

using namespace std;

template<typename K, typename V>
class HashMap : public HashMapInterface<K,V> {



private:

    Pair<K,V>* pairs;
    size_t capacity;
    size_t numItems = 0;

    /*template<typename J>
    struct hash
    {
        size_t operator()(const J& Key)
        {
            return 0;
        }
    };
    template<>
    struct hash<string> {

        size_t operator()(const string& b) {
            size_t hash = 0;
            for(size_t i = 0; i < b.length(); i++) {
                hash = hash * HASH_CONSTANT + b[i];
            }
            return hash;
        }
    };
     */

public:

    HashMap() {
        capacity = DEFAULT_MAP_HASH_TABLE_SIZE;
        pairs = new Pair<K,V>[DEFAULT_MAP_HASH_TABLE_SIZE];
    }
    ~HashMap() {
        clear();
    }

    size_t Hash(const K& key) {
        size_t index = 0;
        for(size_t i = 0; i < key.size(); ++i) {
            index = index * 3 + key[i];
        }
        return index;
    }
/** Read/write index access operator.
    If the key is not found, an entry is made for it.
    @return: Read and write access to the value mapped to the provided key. */
      V& operator[](const K& key) {

      size_t index = Hash(key) % capacity;
       size_t i = 1;
       if((size() * 100) / capacity >= LOAD_THRESHOLD) {
           Rehash();
       }
      while(1)
      {
         if(pairs[index].first != K()) {

          if(pairs[index].first == key) {
              break;
          }
          index = (index + ( i * i) - ((i - 1) * (i -1)) ) % capacity;
          i = i + 1;
          continue;
         }
         numItems = numItems + 1;
         pairs[index].first = key;

         break;
      }
      return pairs[index].second;

    }

    void Rehash() {
          size_t newCapacity = capacity * 2;
          Pair<K,V>* newPairs = new Pair<K,V>[newCapacity];
          size_t k = 1;

          for(int i = 0; i < capacity; ++i) {
              if(pairs[i].first != "") {

                  size_t newHashIndex = Hash(pairs[i].first) % newCapacity;
                  if(newPairs[newHashIndex].first == pairs[i].first) {
                      continue;
                  }
                  while(newPairs[newHashIndex].first != "") {
                      newHashIndex = (newHashIndex + ((k * k)) - ((k-1) * (k -1)) % newCapacity);
                      k+=1;
                  }
                  newPairs[newHashIndex].first = pairs[i].first;
                  newPairs[newHashIndex].second = pairs[i].second;
              }
          }
          capacity = newCapacity;
          swap(pairs,newPairs);
          delete [] newPairs;




      }
    /** @return: the number of elements that match the key in the Map. */
    size_t count(const K& key) {

        for(size_t i = 0; i < capacity; ++i) {
            if(key == pairs[i].first) {
                return 1;
            }
        }
        return 0;


    }
    /** Removes all items from the Map. */
    void clear(void) {
      delete [] pairs;
      pairs = NULL;


    }


    /** @return: number of Key-Value pairs stored in the Map. */
    size_t size(void) const {
       return numItems;
    }
    /** @return: maximum number of Key-Value pairs that the Map can hold. */
     size_t max_size(void) const {
         return capacity;
    }
    /** @return: string representation of Key-Value pairs in Map. */
    std::string toString(void) const {
         stringstream out;
         out << size() << "/" << capacity << endl;
        for(int i = 0; i < capacity; ++i) {
              if(pairs[i].first != K()) {
                 out << "[" << i << ":" << pairs[i].first << "->" << pairs[i].second << "]" << endl;
              }
          }
        return out.str();


    }











};












#endif //POKEMON_HASHMAP_H
